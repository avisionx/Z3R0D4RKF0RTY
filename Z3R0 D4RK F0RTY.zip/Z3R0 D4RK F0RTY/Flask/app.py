from flask import Flask, request
from flask_cors import CORS
import final 
import revfinal
app = Flask(__name__)
CORS(app)

@app.route('/request', methods=['POST'])
def request(source, destination):
	json1 = final.func(source, destination)
	json2 = revfinal.func(source, destination)
	dictA = json.loads(json1)
	dictB = json.loads(json2)
	merged_dict = {key: value for (key, value) in (dictA.items() + dictB.items())}
	print(merged_dict)
	return merged_dict

if __name__ == '__main__':
	app.run(host='0.0.0.0', port=5000)