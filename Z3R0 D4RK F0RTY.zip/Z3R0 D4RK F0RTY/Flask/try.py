s = "walk to govinf"
x = s.replace("to","from")
print(x)	